<?php
/**
 * Plugin Name:   Greet
 * Description:   This plugin gives greetings depending on the time of day.
 * Version:       1.2
 * Author:        Indy Bosschem
 */

 function greetings() {
    if ( is_user_logged_in() ) {
      $time = date("G");
      if($tijd < 6) {
          return "Welcome back, Good night.";
      } elseif($time < 12) {
          return "Welcome back, Good morning.";
      } elseif($time < 16){
          return "Welcome back, Good afternoon.";
      } else {
          return "Welcome back, Good evening.";
      }
    } else {
      $time = date("G");
      if($time < 6) {
          return "Good night";
      } elseif($time < 12) {
          return "Good morning";
      } elseif($time < 16){
          return "Good afternoon";
      } else {
          return "Good evening";
      }
    }
 }

 add_shortcode( 'greeting', 'greetings' );

?>
